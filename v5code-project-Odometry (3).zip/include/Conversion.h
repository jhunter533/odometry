#ifndef Conversion
#define Conversion

#include "GlobalVar.h"
double ConvertToDeg(double radians);
double ConvertToRadians(double degree);
void ShortAngle();
#endif